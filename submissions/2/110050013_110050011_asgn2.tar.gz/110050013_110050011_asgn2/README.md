Team members:

Shubham Mehta (110050013)
Rohan Prinja (110050011)

To run the code:

1. compile: javac *.java
2. run: java -Djava.rmi.server.hostname=<your IPv4 address in double quotes> DistributedChat client2 <network interface e.g. wlan0 or eth1>